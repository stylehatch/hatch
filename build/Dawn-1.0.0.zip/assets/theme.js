const sum = (a, b) => {
  return a + b;
};

const A = 4;
const B = 5;
console.log(sum(A, B));
const bar = ['a', 'b', 'c'];
console.log('bar', bar);
console.log('scripts/theme.js');
