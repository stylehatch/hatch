console.log('section - scripts/sections/image-banner.js');
